package com.qwq0.iiroseforge;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;

import android.os.Environment;
import android.view.Window;
import android.webkit.*;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        try {
            WebView webView = (WebView) findViewById(R.id.mainWebView);
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);
            webSettings.setBlockNetworkImage(false);
            webSettings.setAppCachePath(Environment.getExternalStorageDirectory().getPath() + "/iiroseForge");
            webSettings.setAppCacheEnabled(true);
            webSettings.setDomStorageEnabled(true);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
                webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            }
            webView.setWebChromeClient(new WebChromeClient() {
                public void onProgressChanged(WebView view, int progress) {
                    if (progress == 100) {
                        webView.evaluateJavascript("javascript:(function(d,s){s=d.createElement(\"script\");s.src=\"//qwq0.rthe.xyz/iirose/l.js\";d.body.appendChild(s);})(document)", new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                            }
                        });
                    }
                }
            });
            webView.loadUrl("https://iirose.com");
        } catch (Exception err) {
            System.err.print(err);
        }
    }
}